import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MedicalGUI extends JFrame {

    JLabel title;
    JLabel address;
    JLabel medicineName;
    JLabel price;
    JLabel quantity;
    JLabel expiry;
    JComboBox<String> medicineNameBox;
    JTextField priceBox;
    JTextField quantityBox;
    JTextField expiryBox;
    JButton add;
    JButton update;
    JButton delete;
    JButton processBill;
    JButton clear;
    JList<String> medicineList;

    JLabel totalPriceLabel;
    JLabel totalPriceValue;
    JLabel gst;
    JLabel gstValue;
    JLabel priceAfterGstLabel;
    JLabel priceAfterGstValue;


    JPanel homepage;
    JPanel buttons;
    JScrollPane listscroll;

    GridBagConstraints gbc;


    List<Medicine> listOfMedicines = new ArrayList<>();

    public MedicalGUI() {
        this.setName("Pharmacy Billing System");
        this.setSize(700, 600);
        this.setLayout(new CardLayout());
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.title = new JLabel("Pharmacy Billing");
        this.address = new JLabel("Phone: 52425135632                      Email: jkpharmacy@gmail.com                          Coimbatore");
        this.medicineName = new JLabel("Medicine Name");
        this.price = new JLabel("Price");
        this.quantity = new JLabel("Quantity");
        this.expiry = new JLabel("Expiry Date");
        String[] medicineNames = {"Select"};
        this.medicineNameBox = new JComboBox<>(medicineNames);
        this.priceBox = new JTextField(20);
        this.quantityBox = new JTextField(20);
        this.expiryBox = new JTextField(20);
        this.add = new JButton("Add");
        this.update = new JButton("Update");
        this.delete = new JButton("Delete");
        this.processBill = new JButton("Bill");
        this.clear = new JButton("Clear");
        DefaultListModel<String> listitems = new DefaultListModel<>();
        listitems.addElement("%-40s %15s %15s %15s".formatted("Medicine Name", "Price", "Quantity", "Total Price"));
        this.medicineList = new JList<>(listitems);
        this.homepage = new JPanel(new GridBagLayout());
        this.buttons = new JPanel(new GridBagLayout());
        this.listscroll = new JScrollPane(medicineList);
        this.totalPriceLabel = new JLabel("Total Price");
        this.totalPriceValue = new JLabel("0");
        this.gst = new JLabel("GST 18%");
        this.gstValue = new JLabel("0");
        this.priceAfterGstLabel = new JLabel("Price after GST");
        this.priceAfterGstValue = new JLabel("0");
        medicineList.setFont(new Font("Monospaced", Font.PLAIN, 12));

        gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 10, 0, 10);
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;

        homepage.add(title, gbc);

        gbc.gridy = 1;

        homepage.add(address, gbc);

        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        homepage.add(medicineName, gbc);

        gbc.gridx = 1;
        medicineNameBox.setPreferredSize(new Dimension(200, 25));

        homepage.add(medicineNameBox, gbc);

        gbc.gridx = 2;

        homepage.add(expiry, gbc);

        gbc.gridx = 3;

        homepage.add(expiryBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;

        homepage.add(price, gbc);

        gbc.gridx = 1;

        homepage.add(priceBox, gbc);

        gbc.gridx = 2;

        homepage.add(quantity, gbc);

        gbc.gridx = 3;

        homepage.add(quantityBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        buttons.add(add, gbc);

        gbc.gridx = 1;

        buttons.add(update, gbc);

        gbc.gridx = 2;

        buttons.add(delete, gbc);

        gbc.gridx = 4;

        buttons.add(clear, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 4;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        homepage.add(buttons, gbc);

        gbc.fill = GridBagConstraints.NONE;
        gbc.gridy = 5;

        listscroll.setPreferredSize(new Dimension(650, 300));
        homepage.add(listscroll, gbc);

        gbc.gridx = 2;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 0, 15);
        homepage.add(totalPriceLabel, gbc);

        gbc.gridx = 2;
        gbc.gridy = 7;

        homepage.add(gst, gbc);

        gbc.gridx = 2;
        gbc.gridy = 8;
        homepage.add(priceAfterGstLabel, gbc);


        gbc.gridx = 3;
        gbc.gridy = 6;
        gbc.anchor = GridBagConstraints.EAST;
        homepage.add(totalPriceValue, gbc);

        gbc.gridx = 3;
        gbc.gridy = 7;
        homepage.add(gstValue, gbc);

        gbc.gridx = 3;
        gbc.gridy = 8;
        homepage.add(priceAfterGstValue, gbc);


        this.add(homepage);
        this.createMedicines();
        this.populateMedicineNames();
        this.setVisible(true);

        medicineNameBox.addActionListener(e -> {
            String name = (String) medicineNameBox.getSelectedItem();
            if (!name.equalsIgnoreCase("select")) {
                Medicine medicine = this.getMedicine(name);
                priceBox.setText(String.valueOf(medicine.getPrice()));
                expiryBox.setText(medicine.getExpiryDate());
            }
        });

        add.addActionListener(e -> {
            String name = (String) medicineNameBox.getSelectedItem();
            int price = Integer.parseInt(priceBox.getText());
            int quantity = Integer.parseInt(quantityBox.getText());
            int total = price * quantity;
            listitems.addElement("%-40s %15d %15d %15d".formatted(name, price, quantity, total));
            int totalPrice = Integer.parseInt(totalPriceValue.getText());
            totalPrice += total;
            totalPriceValue.setText(String.valueOf(totalPrice));
            this.calculateGstAndPrice();
        });

        medicineList.addListSelectionListener(e -> {
            String s = medicineList.getSelectedValue();
            if (s != null) {
                String[] allitem = medicineList.getSelectedValue().split(" ");
                String[] items = getListElementValues(allitem);
                medicineNameBox.setSelectedItem(items[0]);
                priceBox.setText(items[1]);
                quantityBox.setText(items[2]);
            }
        });

        delete.addActionListener(e -> {
            int price = Integer.parseInt(priceBox.getText());
            int quty = Integer.parseInt(quantityBox.getText());
            int totalPrice = Integer.parseInt(totalPriceValue.getText());
            totalPrice -= price * quty;
            listitems.removeElementAt(medicineList.getSelectedIndex());
            totalPriceValue.setText(String.valueOf(totalPrice));
            calculateGstAndPrice();
        });

        update.addActionListener(e -> {
            int ind = medicineList.getSelectedIndex();
            String name = (String) medicineNameBox.getSelectedItem();
            int price = Integer.parseInt(priceBox.getText());
            int quantity = Integer.parseInt(quantityBox.getText());
            int totalPrice = Integer.parseInt(totalPriceValue.getText());
            String[] items = getListElementValues(medicineList.getSelectedValue().split(" "));
            int prevQty = Integer.parseInt(items[2]);

            totalPrice -= prevQty * price;
            totalPrice += quantity * price;
            totalPriceValue.setText(String.valueOf(totalPrice));

            listitems.removeElementAt(ind);
            listitems.add(ind, "%-40s %15d %15d %15d".formatted(name, price, quantity, price * quantity));
            calculateGstAndPrice();
        });

        clear.addActionListener(e -> {
            medicineNameBox.setSelectedItem("Select");
            priceBox.setText("");
            quantityBox.setText("");
            expiryBox.setText("");
            listitems.clear();
            listitems.addElement("%-40s %15s %15s %15s".formatted("Medicine Name", "Price", "Quantity", "Total Price"));
            totalPriceValue.setText("0");
            gstValue.setText("0");
            priceAfterGstValue.setText("0");
        });


    }

    public String[] getListElementValues(String[] allitem) {
        String[] items = new String[4];
        int n = 0;
        for (int i = 0; i < allitem.length; i++) {
            if (allitem[i].length() != 0) {
                items[n++] = allitem[i];
            }
        }
        return items;
    }

    private void calculateGstAndPrice() {
        int totalPrice = Integer.parseInt(totalPriceValue.getText());
        int gst = totalPrice * 18 / 100;
        int priceAfterGst = totalPrice - gst;
        gstValue.setText(String.valueOf(gst));
        priceAfterGstValue.setText(String.valueOf(priceAfterGst));
    }

    public void populateMedicineNames() {
        listOfMedicines.forEach(medi -> medicineNameBox.addItem(medi.getMedicineName()));
    }

    public void createMedicines() {
        listOfMedicines.add(new Medicine("Paracetamol", 10, 500, "12-8-2026"));
        listOfMedicines.add(new Medicine("Aspirin", 15, 500, "11-5-2025"));
        listOfMedicines.add(new Medicine("Ibuprofen", 20, 500, "22-8-2028"));
        listOfMedicines.add(new Medicine("Pantoprazole", 40, 500, "2-1-2029"));
        listOfMedicines.add(new Medicine("Cetirizine", 15, 500, "8-10-2030"));
        listOfMedicines.add(new Medicine("Amoxicillin", 30, 500, "7-11-2027"));
        listOfMedicines.add(new Medicine("Metformin", 80, 500, "3-12-2026"));
        listOfMedicines.add(new Medicine("Azithromycin", 60, 500, "5-9-20275"));
        listOfMedicines.add(new Medicine("Cough Syrup", 60, 500, "14-5-2027"));
        listOfMedicines.add(new Medicine("DiclofenacGel", 15, 500, "16-3-2027"));
        listOfMedicines.add(new Medicine("VitaminC", 20, 500, "20-7-2028"));

    }

    public Medicine getMedicine(String name) {
        for (Medicine m : listOfMedicines) if (m.getMedicineName().equals(name)) return m;
        return null;
    }
}
