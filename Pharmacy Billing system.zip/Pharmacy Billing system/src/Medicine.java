public class Medicine {
    private String medicineName;
    private int price;
    private int availableQuantity;
    private String expiryDate;

    public Medicine(String medicineName, int price, int availableQuantity, String expiryDate) {
        this.medicineName = medicineName;
        this.price = price;
        this.availableQuantity = availableQuantity;
        this.expiryDate = expiryDate;
    }

    public String getMedicineName() {
        return medicineName;
    }

    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getAvailableQuantity() {
        return availableQuantity;
    }

    public void setAvailableQuantity(int availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }
}
